import sys

print(sys.shenanigans)
