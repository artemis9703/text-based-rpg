from pyscript import document, window

document.body.append(window.Date.now() - window.start)
