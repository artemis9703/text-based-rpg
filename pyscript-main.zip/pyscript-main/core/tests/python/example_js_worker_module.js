/*
A simple JavaScript module to test the integration with Python on a worker.
*/

export function hello() {
    return "Hello from JavaScript in a web worker!";
}
