/*
A simple JavaScript module to test the integration with Python.
*/

export function hello() {
    return "Hello from JavaScript!";
}
