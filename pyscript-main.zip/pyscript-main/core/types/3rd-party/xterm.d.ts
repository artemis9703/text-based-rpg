declare var D: any;
declare var R: any;
declare var L: {};
export { D as Terminal, R as __esModule, L as default };
