declare var r: any;
declare var n: any;
declare var t: {};
export { r as WebLinksAddon, n as __esModule, t as default };
