import sys


def version():
    return sys.version
