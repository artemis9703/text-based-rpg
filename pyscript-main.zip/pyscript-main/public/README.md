# Public

The `index.html` file found in this directory is used by the GitHub Actions
(defined in this repo's `.github/workflows/` directory) as a template for the
static page used to collate all the information relating to a release of
PyScript. Such static pages (and related release assets) eventually end up on
the https://pyscript.net/ domain.
